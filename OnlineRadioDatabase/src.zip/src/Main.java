
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);
        int total=0;
        int count=0;
        Song song = null;
        String artName = "";
        String songName = "";
        String length = "";
        int minutes =0;
        int seconds =0;
        int n = Integer.parseInt(scanner.nextLine());
        SongDatabase songDatabase=new SongDatabase();
        while (n-- > 0) {

            String input = scanner.nextLine();
            String[] tokens = input.split(";");
            artName = tokens[0];
            songName = tokens[1];
            length = tokens[2];



            try {
                String[] vreme = tokens[2].split(":");
                song = new Song(artName, songName, length);

                songDatabase.addSong(song);
                count++;
                System.out.println("Song added.");

                minutes = Integer.parseInt(vreme[0]);
                seconds = Integer.parseInt(vreme[1]);
                int len=minutes*60+seconds;

                total=total+len;
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }

            //            input = scanner.nextLine();
        }
        int chas=total/3600;
        minutes=(total-chas*3600)/60;
        seconds=(total-chas*3600)%60;
//      if(minutes==60){
//          chas++;
//          minutes=0;
//      }
        System.out.printf("Songs added: %d%n",count);
        System.out.printf("Playlist length: %dh %dm %ds",chas,minutes,seconds);

    }
}
