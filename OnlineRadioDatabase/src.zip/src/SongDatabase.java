import java.util.ArrayList;
import java.util.List;

public class SongDatabase {

    private List<Song> songs;

    public SongDatabase() {
        songs = new ArrayList<>();
    }
    public void addSong(Song song){
        this.songs.add(song);
    }
    public String getTotalLengthOfSongs(){
       return "Songs added: " + this.songs.size();
    }
}
