public class Main1 {

    public static void main(String[] args) {

        try {
            SongDatabase database = new SongDatabase();
            database.addSong(new Song("Nasko Mentata","Shushana","14:0"));

        } catch (InvalidSongException e) {
            e.printStackTrace();
        }

    }
}
